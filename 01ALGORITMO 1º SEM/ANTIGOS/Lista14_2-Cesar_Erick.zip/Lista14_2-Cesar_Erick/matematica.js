
function validar(valores){
    
for (let i = 0; i < valores.length; i++){
    
    if (valores[i] == null || valores[i] == undefined) return `Parâmetro ${valores[i]} não pode ser nulo ou indefinido`
    if (typeof valores[i] != "number") return `Tipo inválido para o argumento ${valores[i]}`
}

return 'valido'

}


function somar(num1, num2){
console.log("-----função Somar: -----")
    let validacao = validar(num1,num2)
    if (validacao == 'valido'){

    let soma = num1 + num2;
         return soma
    } else return validacao
    

  
        
    
}

function distancia([x1,y1,x2,y2]){
    console.log("-----Função calcular distância:-----")
let validacao = validar([x1,y1,x2,y2])

  if (validacao == 'valido'){
    let calculo = ((((x2-x1) *(x2-x1)) + ((y2-y1) * (y2-y1)))) ** 1/2
    return calculo

  }else return validacao

}



 function converterParaHoraMinutoSegundo(numero){
    console.log("-----Função converter horário: -----")
    let validacao = validar(numero)
    let min = 0;
    let hr = 0;

    if (validacao == 'valido'){
    while (numero > 59){
        numero -= 60;
        min ++
        while (min > 59){
            min -= 60;
            hr ++;
        }
}
    return (hr + " : " + min + " : " + numero)
    } else return validacao

 }



 function ePrimo(numero){
    console.log("-----Função verificar número primo: -----")
    let validacao = validar(numero)
    let primo = true;
    if (validacao == "valido"){
    for (let i = 0; i <= numero; i++)
    {
        if (i != numero && i != 1 && numero % i == 0){
        
            primo = false
            break
        }
    }
    if (primo) return true
    if (primo == false) return false

 } return validacao
}



 function calcularFatorial(numero){
    console.log("-----Função calcular fatorial: -----")
    let validacao = validar(numero)
    let fatorial = 1;
    if (validacao == 'valido'){
        for (let i = 1; i <= numero; i++){
            fatorial *= i
        }
        return fatorial
    } else return validacao
    
 }

 function calcularMedia(vetor){
    console.log("-----Função calcular média: -----")
    let validacao = validar(vetor)
    let soma = 0;
    let media = 0;
    if (validacao == 'valido'){
        for (let i = 0; i < vetor.length; i++){
            soma += vetor[i]
        }
        media = soma / vetor.length
        return media
    } else return validacao
 }

 function calcularMediaPonderada(vetorMedias, vetorPesos){
    console.log("-----Função calcular média ponderada: -----")
    let validacao = validar(vetorMedias, vetorPesos)
    let soma = 0;
    let media = 0;
    if (validacao == 'valido'){
        for (let i = 0; i < vetorMedias.length; i++){
            soma += vetorMedias[i] * vetorPesos[i]
        }
        media = soma 
        return media
    } else return validacao
 }


